﻿/*

@Name：不落阁整站模板源码 
@Author：Absolutely 
@Site：http://www.lyblogs.cn
*/

prettyPrint();
layui.use(['layer','form', 'layedit'], function () {
    var form = layui.form();
    var $ = layui.jquery;
    var layedit = layui.layedit;

    //评论和留言的编辑器
    var editIndex = layedit.build('remarkEditor', {
        height: 150,
        tool: ['face', '|', 'left', 'center', 'right', '|', 'link'],
    });
    //评论和留言的编辑器的验证
    layui.form().verify({
        content: function (value) {
            value = $.trim(layedit.getContent(editIndex));
            if (value == "") return "至少得有一个字吧";
            layedit.sync(editIndex);
        }
    });
     //监听评论提交
    form.on('submit(formRemark)', function (data) {
        console.log(data.field);
        var index = layer.load(1);
        $.ajax({
            url:'/article/postComment',
            data:data.field,
            type:'post',
            success:function(result){
                var code = result.errorCode;
                var message = result.message;
                layer.close(index);
                console.info(JSON.stringify(result));
                if(code=="9"){
                    layer.msg(message, { icon: 5 });
                }else{
                    layer.msg("评论成功", { icon: 1 });
                    setTimeout(function(){
                        location.reload();
                    },1000);
                }
            },
            error:function(){
               layer.msg("评论失败", { icon: 5 });
            }
        });
        return false;
    });
    
    //回复按钮点击事件
    $('.btn-reply').on('click', function () {
        var targetId = $(this).data('targetid')
            , targetName = $(this).data('targetname')
            , $container = $(this).parent('p').parent().siblings('.replycontainer');
        if ($(this).text() == '回复') {
            $container.find('textarea').attr('placeholder', '回复【' + targetName + '】');
            $container.removeClass('layui-hide');
            $container.find('input[name="targetUserId"]').val(targetId);
            $(this).parents('.blog-comment li').find('.btn-reply').text('回复');
            $(this).text('收起');
        } else {
            $container.addClass('layui-hide');
            $container.find('input[name="targetUserId"]').val(0);
            $(this).text('回复');
        }
    });

    //监听留言回复提交
    form.on('submit(formReply)', function (data) {
        if ($(data.elem).hasClass('layui-btn-disabled')) {
            return false;
        }
        var index = layer.load(1);
        $.ajax({
            type: 'post',
            url: '/api/article/reply',
            data: data.field,
            success: function (res) {
                layer.close(index);
                if (res.code === 1) {
                    layer.msg(res.msg, { icon: 6 });
                    setTimeout(function () {
                        location.reload(true);
                    }, 500);
                } else {
                    if (res.msg != undefined) {
                        layer.msg(res.msg, { icon: 5 });
                    } else {
                        layer.msg('程序异常，请重试或联系作者', { icon: 5 });
                    }
                }
            },
            error: function (e) {
                layer.close(index);
                layer.msg("请求异常", { icon: 2 });
            }
        });
        return false;
    });
});
